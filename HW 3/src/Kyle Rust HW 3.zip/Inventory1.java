/**
 * Extends the Sorting class and sets an initial sorting algorithm
 */
public class Inventory1 extends Sorting {
    public Inventory1(){
        sortingStrategy = new bubbleSort();
    }
}
